

import 'package:flutter/src/painting/text_style.dart';
import 'package:google_fonts/google_fonts.dart';

class Fonts {
  static TextStyle labelFont = GoogleFonts.acme();
}