class SupabaseKeys {
  // supabase project url.
  static const String url = 'https://vivzsxjjtzjnrsjewjlt.supabase.co';

  // supabase anonkey.
  static const String anonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZpdnpzeGpqdHpqbnJzamV3amx0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTI0MjA4ODMsImV4cCI6MjA2Nzk5Njg4M30.piBvH1krPTMFE65E7p0tpZYPrMGnSv3A7cWx6Q4vleg';
}
